Adafruit-TMP006-and-TMP007-PCB
==============================

PCB files for Adafruit TMP006 and TMP007 (same layout, different silkscreen)

These are the Eagle CAD files for the Adafruit TMP006/TMP007 sensor breakout:

  ----> https://www.adafruit.com/products/1296

  ----> https://www.adafruit.com/products/2023

Adafruit invests time and resources providing this open source design, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Designed by Limor Fried/Ladyada for Adafruit Industries.
Creative Commons Attribution/Share-Alike, all text above must be included in any redistribution